"""EduRAG — AI Academic Document Assistant package."""
__version__ = "1.0.0"
