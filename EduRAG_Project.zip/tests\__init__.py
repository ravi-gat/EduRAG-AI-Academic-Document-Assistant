"""EduRAG test suite."""
